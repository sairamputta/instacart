the following data files should be placed in this directory
- aisles.csv
- departments.csv
- order_products__prior.csv
- order_products__train.csv
- orders.csv
- products.csv
